import { IndianAmountInput } from './IndianAmountInput';
import { apiFetch } from '../utils/api';
import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Calendar,
  Wallet,
  DollarSign,
  CreditCard,
  Search,
  Filter,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  Coffee,
  Fuel,
  Home,
  Users,
  Truck,
  Layers,
  Utensils,
  Wrench,
  FileText,
} from 'lucide-react';
import { AppSettings, Expense } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';
import { playSuccessTone, triggerHaptic } from '../utils/feedback';

export const EXPENSE_CATEGORIES = [
  { name: 'food', icon: Utensils },
  { name: 'Manufacturing Expense', icon: Wrench },
  { name: 'Petrol', icon: Fuel },
  { name: 'Rent', icon: Home },
  { name: 'Salary', icon: Users },
  { name: 'Tea', icon: Coffee },
  { name: 'Transport', icon: Truck },
  { name: 'Office Expense', icon: FileText },
  { name: 'Miscellaneous', icon: Layers },
];

export const PAYMENT_MODES = [
  { id: 'Cash', label: 'Cash' },
  { id: 'Cheque', label: 'Cheque' },
  { id: 'Bank', label: 'Online / Bank' },
];

interface ExpenseModalProps {
  isOpen: boolean;
  settings: AppSettings;
  language: string;
  onClose: () => void;
  onExpenseAdded?: () => void;
  userMobile?: string;
  initialAddOpen?: boolean;
}

export const ExpenseModal: React.FC<ExpenseModalProps> = ({
  isOpen,
  settings,
  onClose,
  onExpenseAdded,
  userMobile = '',
  initialAddOpen = false,
}) => {
  // View tabs: 'categories' | 'items' (matching video 00:08 - 00:09)
  const [activeTab, setActiveTab] = useState<'categories' | 'items'>('categories');
  const [isAddFormOpen, setIsAddFormOpen] = useState(initialAddOpen);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');

  // Live Expenses Data
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [overallTotal, setOverallTotal] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Manual Form State - STRICT MANUAL ENTRY ONLY, NO AI, ALL ENGLISH, BLUE THEME
  const [formCategory, setFormCategory] = useState<string>('food');
  const [formTitle, setFormTitle] = useState<string>('');
  const [formAmount, setFormAmount] = useState<string>('');
  const [formDate, setFormDate] = useState<string>(() => new Date().toLocaleDateString('en-GB'));
  const [formPaymentMode, setFormPaymentMode] = useState<string>('Cash');
  const [formNote, setFormNote] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch expenses from database
  const loadExpenses = async () => {
    setLoading(true);
    try {
      const headers: Record<string, string> = userMobile ? { 'x-user-mobile': userMobile } : {};
      const res = await apiFetch('/api/expenses', { headers });
      if (res.ok) {
        const data = await res.json();
        setExpenses(data.expenses || []);
        setOverallTotal(data.totalAmount || 0);
      }
    } catch (err: any) {
      console.error('Failed to load expenses:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadExpenses();
    }
  }, [isOpen, userMobile]);

  // Handle Manual Form Submission
  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(formAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMsg('Please enter a valid expense amount.');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        ...(userMobile ? { 'x-user-mobile': userMobile } : {}),
      };

      const payload = {
        expense_no: `EXP-${Date.now().toString().slice(-4)}`,
        date: formDate,
        category: formCategory,
        title: formTitle.trim() || formCategory,
        amount: numAmount,
        payment_mode: formPaymentMode.toUpperCase(),
        notes: formNote.trim(),
      };

      const res = await apiFetch('/api/expenses', {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        triggerHaptic(28);
        playSuccessTone();
        setFormTitle('');
        setFormAmount('');
        setFormNote('');
        setIsAddFormOpen(false);
        await loadExpenses();
        if (onExpenseAdded) onExpenseAdded();
      } else {
        const err = await res.json();
        setErrorMsg(err.error || 'Failed to save expense.');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Network error occurred.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete Expense
  const handleDeleteExpense = async (id: string) => {
    if (!window.confirm('Delete this expense?')) return;
    triggerHaptic(24);
    try {
      const res = await apiFetch(`/api/expenses/${id}`, {
        method: 'DELETE',
        headers: userMobile ? { 'x-user-mobile': userMobile } : {},
      });
      if (res.ok) {
        await loadExpenses();
        if (onExpenseAdded) onExpenseAdded();
      }
    } catch (err: any) {
      console.error('Delete expense error:', err);
    }
  };

  // Filtered Expense list
  const filteredExpenses = expenses.filter((exp) => {
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const matchTitle = (exp.title || '').toLowerCase().includes(query);
      const matchCat = (exp.category || '').toLowerCase().includes(query);
      if (!matchTitle && !matchCat) return false;
    }
    return true;
  });

  // Calculate Category Totals matching video 00:09
  const categoryStats = EXPENSE_CATEGORIES.map((cat) => {
    const matching = expenses.filter((e) => (e.category || '').toLowerCase() === cat.name.toLowerCase());
    const total = matching.reduce((sum, e) => sum + parseFloat(String(e.amount || '0')), 0);
    return {
      ...cat,
      total,
      count: matching.length,
    };
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs font-sans">
      <div 
        className="w-full max-w-2xl h-[92dvh] flex flex-col rounded-2xl border border-slate-200 bg-slate-50 shadow-2xl overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Header Bar (Matching Video 00:08) */}
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3 bg-white shrink-0 shadow-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base sm:text-lg font-bold text-slate-900">Expense</h1>
          </div>
          <button className="p-1.5 text-slate-600 hover:text-slate-900">
            <Search className="w-5 h-5" />
          </button>
        </div>

        {/* Two Tabs: Categories & Items (Matching Video 00:08) */}
        <div className="flex bg-white border-b border-slate-200 px-4 shrink-0">
          <button
            onClick={() => setActiveTab('categories')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-all cursor-pointer ${
              activeTab === 'categories'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Categories
          </button>
          <button
            onClick={() => setActiveTab('items')}
            className={`flex-1 py-3 text-xs font-bold text-center border-b-2 transition-all cursor-pointer ${
              activeTab === 'items'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Items
          </button>
        </div>

        {/* Total Summary Row (Matching Video 00:09) */}
        <div className="flex justify-end py-2 px-4 text-xs shrink-0">
          <span className="text-slate-500 mr-2 font-medium">Total:</span>
          <span className="font-bold font-mono text-blue-600">
            {formatCurrency(overallTotal, settings.currency)}
          </span>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto px-4 pb-28 space-y-2">
          
          {/* TAB 1: CATEGORIES (Exact list from video 00:09) */}
          {activeTab === 'categories' && (
            <div className="bg-white rounded-xl border border-slate-200 divide-y divide-slate-100 shadow-2xs overflow-hidden">
              {categoryStats.map((cat, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setFormCategory(cat.name);
                    setIsAddFormOpen(true);
                  }}
                  className="py-3.5 px-4 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <span className="text-xs font-semibold text-slate-800">{cat.name}</span>
                  <span className="text-xs font-mono font-bold text-slate-800">
                    {formatCurrency(cat.total, settings.currency)}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* TAB 2: ITEMS */}
          {activeTab === 'items' && (
            <div className="space-y-2">
              {filteredExpenses.length === 0 ? (
                <div className="bg-white rounded-xl border border-slate-200 p-12 text-center text-slate-400 text-xs shadow-2xs">
                  No itemized expenses recorded yet. Click "+ Add Expenses" below to create one.
                </div>
              ) : (
                filteredExpenses.map((exp) => (
                  <div
                    key={exp.id}
                    className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-xs text-slate-900">{exp.title || exp.category}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {exp.date} • {exp.category} • {exp.payment_mode || 'Cash'}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="font-mono font-bold text-sm text-slate-900">
                        {formatCurrency(exp.amount, settings.currency)}
                      </div>
                      <button
                        onClick={() => handleDeleteExpense(exp.id)}
                        className="text-slate-300 hover:text-rose-600 transition-colors p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

        </div>

        {/* Floating Action Button: + Add Expenses (Centered, Blue Theme) */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-30">
          <button
            onClick={() => setIsAddFormOpen(true)}
            className="flex items-center gap-2 px-7 py-3 rounded-full bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs uppercase tracking-wider shadow-xl shadow-blue-600/35 hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Expenses</span>
          </button>
        </div>

        {/* Modal: Add Expense Form (Pure English, Blue Theme) */}
        {isAddFormOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
            <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl p-5 space-y-4 font-sans">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-bold text-base text-slate-900">Record New Expense</h3>
                <button
                  onClick={() => setIsAddFormOpen(false)}
                  className="p-1 rounded-full text-slate-400 hover:text-slate-700"
                >
                  ✕
                </button>
              </div>

              {errorMsg && (
                <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                  {errorMsg}
                </div>
              )}

              <form onSubmit={handleSaveExpense} className="space-y-3.5 text-xs">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Expense Category</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 bg-white font-semibold text-slate-800 focus:border-blue-600 focus:outline-none"
                  >
                    {EXPENSE_CATEGORIES.map((c) => (
                      <option key={c.name} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Description / Item</label>
                  <input
                    type="text"
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-800"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">Amount (₹) *</label>
                    <IndianAmountInput
                      min="0.01"
                      required
                      value={formAmount}
                      onValueChange={setFormAmount}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono font-bold text-slate-900 focus:border-blue-600 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Date</label>
                    <input
                      type="text"
                      value={formDate}
                      onChange={(e) => setFormDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-mono text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Payment Type</label>
                  <div className="grid grid-cols-3 gap-2">
                    {PAYMENT_MODES.map((pm) => (
                      <button
                        key={pm.id}
                        type="button"
                        onClick={() => setFormPaymentMode(pm.id)}
                        className={`py-2 rounded-xl font-bold text-xs border transition-colors cursor-pointer ${
                          formPaymentMode === pm.id
                            ? 'border-blue-600 bg-blue-50 text-blue-600'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {pm.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Note (Optional)</label>
                  <input
                    type="text"
                    value={formNote}
                    onChange={(e) => setFormNote(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-slate-800"
                  />
                </div>

                <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsAddFormOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 font-semibold hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-6 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md shadow-blue-600/30 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? 'Saving...' : 'Save Expense'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
