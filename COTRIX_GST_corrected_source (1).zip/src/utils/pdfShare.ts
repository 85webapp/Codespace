import html2pdf from 'html2pdf.js';

/* ------------------------------------------------------------------ */
/*  Shared PDF download + multi-app share helpers (Invoices & Reports) */
/* ------------------------------------------------------------------ */

export type StatusFn = (message: string | null) => void;

export interface BuildPdfOptions {
  /** Live DOM element to convert. It is cloned, the original is never touched. */
  element: HTMLElement;
  fileName: string;
  /** Layout width (CSS px) the clone is rendered at. A4 portrait ~ 794, A4 landscape ~ 1123. */
  widthPx?: number;
  orientation?: 'portrait' | 'landscape';
  /** Thermal roll: one tall page. */
  thermal?: boolean;
  /** Thermal roll width in mm (58 or 80). Default 80. */
  thermalWidthMm?: number;
  /** Regular paper size. Default a4. */
  pageSize?: 'a4' | 'a5' | 'letter';
  /** Print "Page x of y" at the bottom of every page (regular only). */
  pageNumbers?: boolean;
}

export interface ShareOptions {
  blob: Blob;
  fileName: string;
  title: string;
  text: string;
  onStatus?: StatusFn;
  /** Legacy compatibility only; this implementation never opens a tab. */
  pendingTab?: Window | null;
}

export type ShareResult = 'shared' | 'cancelled' | 'downloaded';

/* ----------------------------- small toast ----------------------------- */

let toastEl: HTMLDivElement | null = null;
let toastTimer: number | undefined;

export const showToast: StatusFn = (message) => {
  if (typeof document === 'undefined') return;
  if (!message) {
    if (toastEl) toastEl.style.display = 'none';
    return;
  }
  if (!toastEl) {
    toastEl = document.createElement('div');
    toastEl.setAttribute('data-pdf-ignore', 'true');
    toastEl.style.cssText =
      'position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:100000;' +
      'background:rgba(15,23,42,.96);color:#fff;padding:10px 18px;border-radius:999px;' +
      'font:700 12px system-ui,sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.35);max-width:90vw;text-align:center;';
    document.body.appendChild(toastEl);
  }
  toastEl.textContent = message;
  toastEl.style.display = 'block';
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => {
    if (toastEl) toastEl.style.display = 'none';
  }, 3500);
};

/* ------------------------ colour compatibility -------------------------- */
/* html2canvas cannot parse modern CSS colours (oklch, oklab, color-mix ...)
   which Tailwind v4 uses. Every colour is converted to plain rgb()/rgba(). */

const MODERN_COLOR = /(oklch|oklab|lab|lch|color-mix|color)\((?:[^()]|\([^()]*\))*\)/gi;

let colorCtx: CanvasRenderingContext2D | null = null;

function toRgb(value: string): string {
  try {
    if (!colorCtx) {
      const c = document.createElement('canvas');
      c.width = c.height = 1;
      colorCtx = c.getContext('2d', { willReadFrequently: true });
    }
    if (!colorCtx) return 'rgb(0,0,0)';
    colorCtx.clearRect(0, 0, 1, 1);
    colorCtx.fillStyle = '#000';
    colorCtx.fillStyle = value;
    colorCtx.fillRect(0, 0, 1, 1);
    const [r, g, b, a] = colorCtx.getImageData(0, 0, 1, 1).data;
    return a === 255 ? `rgb(${r},${g},${b})` : `rgba(${r},${g},${b},${(a / 255).toFixed(3)})`;
  } catch {
    return 'rgb(0,0,0)';
  }
}

const COLOR_PROPS = [
  'color',
  'backgroundColor',
  'borderTopColor',
  'borderRightColor',
  'borderBottomColor',
  'borderLeftColor',
  'outlineColor',
  'textDecorationColor',
  'fill',
  'stroke',
] as const;

const COMPOSITE_PROPS = ['boxShadow', 'textShadow', 'backgroundImage'] as const;

function flattenModernColors(root: HTMLElement) {
  const nodes: HTMLElement[] = [root, ...Array.from(root.querySelectorAll<HTMLElement>('*'))];
  for (const el of nodes) {
    const cs = window.getComputedStyle(el);
    const style = el.style as any;
    for (const prop of COLOR_PROPS) {
      const v = (cs as any)[prop] as string;
      if (v && MODERN_COLOR.test(v)) style[prop] = toRgb(v);
      MODERN_COLOR.lastIndex = 0;
    }
    for (const prop of COMPOSITE_PROPS) {
      const v = (cs as any)[prop] as string;
      if (v && v !== 'none' && MODERN_COLOR.test(v)) {
        MODERN_COLOR.lastIndex = 0;
        style[prop] = v.replace(MODERN_COLOR, (m) => toRgb(m));
      }
      MODERN_COLOR.lastIndex = 0;
    }
  }
}

/* --------------------------- PDF generation ----------------------------- */

const waitForImages = async (root: HTMLElement) => {
  await Promise.all(Array.from(root.querySelectorAll('img')).map((img) => {
    if (img.complete) return Promise.resolve();
    return new Promise<void>((resolve) => {
      const finish = () => resolve();
      img.addEventListener('load', finish, { once: true });
      img.addEventListener('error', finish, { once: true });
      // A broken/slow remote image must not hang export forever.
      window.setTimeout(finish, 8000);
    });
  }));
  if ('fonts' in document && document.fonts?.ready) {
    await Promise.race([document.fonts.ready.catch(() => undefined), new Promise<void>(r => window.setTimeout(r, 3000))]);
  }
}

/** Clone an element off-screen at a fixed width so the PDF looks the same on phone and desktop. */
async function prepareClone(element: HTMLElement, widthPx: number) {
  const host = document.createElement('div');
  host.setAttribute('aria-hidden', 'true');
  host.style.cssText = `position:fixed;left:-100000px;top:0;width:${widthPx}px;background:#fff;z-index:-1;pointer-events:none;`;

  const clone = element.cloneNode(true) as HTMLElement;
  clone.querySelectorAll('[data-pdf-ignore], .sticky button, script').forEach((n) => n.remove());
  clone.removeAttribute('id');
  clone.style.cssText +=
    `;width:${widthPx}px;max-width:none;min-height:0;height:auto;max-height:none;margin:0;overflow:visible;` +
    'box-shadow:none;transform:none;animation:none;background:#fff;';
  clone.querySelectorAll<HTMLElement>('*').forEach((n) => {
    n.style.animation = 'none';
    n.style.transition = 'none';
  });
  clone.querySelectorAll<HTMLElement>('.sticky').forEach((n) => {
    n.style.position = 'static';
  });
  // Wide tables should never be clipped by their scroll wrapper.
  clone.querySelectorAll<HTMLElement>('[class*="overflow"]').forEach((n) => {
    n.style.overflow = 'visible';
    n.style.maxHeight = 'none';
  });

  host.appendChild(clone);
  document.body.appendChild(host);
  await waitForImages(clone);
  flattenModernColors(clone);
  return { host, clone };
}

export async function buildPdf(opts: BuildPdfOptions): Promise<Blob> {
  const { element, thermal = false, orientation = 'portrait', pageSize = 'a4' } = opts;
  const thermalMm = opts.thermalWidthMm ?? 80;
  const portraitPx = pageSize === 'a5' ? 559 : pageSize === 'letter' ? 816 : 794;
  const landscapePx = pageSize === 'a5' ? 794 : pageSize === 'letter' ? 1056 : 1123;
  const widthPx = opts.widthPx ?? (thermal ? Math.round((thermalMm / 25.4) * 96) : orientation === 'landscape' ? landscapePx : portraitPx);
  const { host, clone } = await prepareClone(element, widthPx);
  try {
    const marginMm = thermal ? 2 : 8;
    let jsPDF: any = { unit: 'mm', format: pageSize, orientation };
    if (thermal) {
      const heightMm = Math.max(60, Math.ceil((clone.scrollHeight * 25.4) / 96) + marginMm * 2 + 2);
      jsPDF = { unit: 'mm', format: [thermalMm, heightMm], orientation: 'portrait' };
    }
    let worker = html2pdf()
      .set({
        margin: marginMm,
        filename: opts.fileName,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: {
          scale: Math.min(3, Math.max(2, (window.devicePixelRatio || 1) + 0.5)),
          useCORS: true,
          allowTaint: false,
          backgroundColor: '#ffffff',
          logging: false,
          scrollX: 0,
          scrollY: 0,
          windowWidth: widthPx,
        },
        jsPDF,
        pagebreak: { mode: ['css', 'legacy'], avoid: ['tr', '.avoid-break', 'thead'], before: '.html2pdf__page-break' },
      })
      .from(clone);
    if (opts.pageNumbers && !thermal) {
      worker = worker
        .toPdf()
        .get('pdf')
        .then((pdf: any) => {
          const total = pdf.internal.getNumberOfPages();
          const w = pdf.internal.pageSize.getWidth();
          const h = pdf.internal.pageSize.getHeight();
          pdf.setFontSize(8);
          pdf.setTextColor(110);
          for (let i = 1; i <= total; i++) {
            pdf.setPage(i);
            pdf.text(`Page ${i} of ${total}`, w / 2, h - 3.5, { align: 'center' });
          }
        });
    }
    const blob: Blob = await worker.outputPdf('blob');
    return blob;
  } finally {
    host.remove();
  }
}

/** Render a DOM element to a PNG Blob for native file sharing without data URLs. */
export async function buildPngBlob(element: HTMLElement, widthPx = 794): Promise<Blob> {
  const { host, clone } = await prepareClone(element, widthPx);
  try {
    const canvas: HTMLCanvasElement = await html2pdf()
      .set({ html2canvas: { scale: 2, useCORS: true, allowTaint: false, backgroundColor: '#ffffff', logging: false, scrollX: 0, scrollY: 0, windowWidth: widthPx } })
      .from(clone)
      .toCanvas()
      .get('canvas');
    const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('Unable to create the business card image.')), 'image/png'));
    return blob;
  } finally { host.remove(); }
}

/** Same clean render as the PDF, returned as a PNG data URL (legacy compatibility). */
export async function buildPng(element: HTMLElement, widthPx = 794): Promise<string> {
  const { host, clone } = await prepareClone(element, widthPx);
  try {
    const canvas: HTMLCanvasElement = await html2pdf()
      .set({
        html2canvas: { scale: 2, useCORS: true, allowTaint: false, backgroundColor: '#ffffff', logging: false, scrollX: 0, scrollY: 0, windowWidth: widthPx },
      })
      .from(clone)
      .toCanvas()
      .get('canvas');
    return canvas.toDataURL('image/png');
  } finally {
    host.remove();
  }
}

/* ------------------------------ download -------------------------------- */

/** Shared, mobile-safe Blob download and native file-sharing primitives. */
const safeFileName = (name: string, extension = '') => {
  const cleaned = (name || 'document').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim() || 'document';
  return extension && !cleaned.toLowerCase().endsWith(extension.toLowerCase()) ? `${cleaned}${extension}` : cleaned;
};

/**
 * Trigger a download from an in-memory Blob without navigating or opening a tab.
 *
 * IMPORTANT: keep the object URL alive long enough for Android Chrome and mobile
 * WebViews to start consuming it. Revoking it on the next task (0ms) can cancel
 * a download before the browser has opened the Blob, which looks like a button
 * that does nothing on phones. The delayed cleanup is intentionally shared by
 * every JSON/PDF export so all download buttons follow the same behavior.
 */
export function downloadBlob(blob: Blob, fileName: string): void {
  if (typeof document === 'undefined' || typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') {
    throw new Error('File downloads are not available in this environment.');
  }
  const payload = blob.type ? blob : new Blob([blob], { type: 'application/octet-stream' });
  const safeName = safeFileName(fileName);
  const legacyNavigator = typeof navigator !== 'undefined'
    ? navigator as Navigator & { msSaveOrOpenBlob?: (data: Blob, name: string) => boolean }
    : null;
  if (legacyNavigator?.msSaveOrOpenBlob) {
    legacyNavigator.msSaveOrOpenBlob(payload, safeName);
    return;
  }

  const objectUrl = URL.createObjectURL(payload);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = safeName;
  anchor.rel = 'noopener';
  anchor.style.position = 'fixed';
  anchor.style.left = '-10000px';
  anchor.style.top = '0';
  anchor.style.width = '1px';
  anchor.style.height = '1px';
  anchor.style.opacity = '0';
  anchor.setAttribute('aria-hidden', 'true');
  (document.body || document.documentElement).appendChild(anchor);
  try {
    // A connected anchor with a filename is the most compatible Blob download
    // mechanism for Android Chrome and desktop browsers.
    anchor.click();
  } catch (error) {
    URL.revokeObjectURL(objectUrl);
    throw error;
  } finally {
    anchor.remove();
    // Do not revoke at 0ms: some mobile browsers begin reading the Blob later.
    // One minute is short enough to avoid leaking URLs but gives downloads time
    // to initialize, including larger invoice/report PDFs on slower phones.
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
  }
}

export function downloadPdf(blob: Blob, fileName: string): void {
  const name = safeFileName(fileName, '.pdf');
  downloadBlob(new Blob([blob], { type: 'application/pdf' }), name);
}

export function downloadJson(data: unknown, fileName: string): void {
  const blob = new Blob([typeof data === 'string' ? data : JSON.stringify(data, null, 2)], {
    type: 'application/json;charset=utf-8',
  });
  downloadBlob(blob, safeFileName(fileName, '.json'));
}

export const canNativeShareFiles = (file?: File): boolean => {
  if (typeof navigator === 'undefined' || typeof navigator.share !== 'function') return false;
  if (!file) return false;
  if (typeof navigator.canShare !== 'function') return false;
  try { return navigator.canShare({ files: [file] }); } catch { return false; }
};

export function openPendingTab(): Window | null { return null; }

export interface ShareFileOptions {
  blob: Blob;
  fileName: string;
  title: string;
  text: string;
  mimeType?: string;
  extension?: string;
  onStatus?: StatusFn;
}

/** Share a generated file through the OS share sheet; any unsupported/cancelled/failed share downloads it. */
export async function shareFile(opts: ShareFileOptions): Promise<ShareResult> {
  const status = opts.onStatus || showToast;
  const mimeType = opts.mimeType || opts.blob.type || 'application/octet-stream';
  const fileName = safeFileName(opts.fileName, opts.extension || '');
  const blob = new Blob([opts.blob], { type: mimeType });
  let file: File | null = null;
  try {
    if (typeof File !== 'undefined') file = new File([blob], fileName, { type: mimeType, lastModified: Date.now() });
  } catch { file = null; }

  if (file && canNativeShareFiles(file)) {
    try {
      await navigator.share({ files: [file], title: opts.title, text: opts.text });
      status('Share sheet completed. Check the selected app to confirm the file was sent.');
      return 'shared';
    } catch (error) {
      // Cancellation is not a failure and must not be reported as a successful share.
      if (error && typeof error === 'object' && 'name' in error && (error as { name?: string }).name === 'AbortError') {
        status('Sharing cancelled. No file was sent.');
        return 'cancelled';
      }
      console.warn('Native file sharing failed; starting download fallback.', error);
    }
  }

  downloadBlob(blob, fileName);
  status('File sharing is unavailable or failed. The file download has started.');
  return 'downloaded';
}

export async function sharePdf(opts: ShareOptions): Promise<ShareResult> {
  return shareFile({
    blob: opts.blob,
    fileName: safeFileName(opts.fileName, '.pdf'),
    title: opts.title,
    text: opts.text,
    mimeType: 'application/pdf',
    extension: '.pdf',
    onStatus: opts.onStatus,
  });
}


export async function downloadImage(element: HTMLElement, fileName: string, widthPx = 1000): Promise<void> {
  const blob = await buildPngBlob(element, widthPx);
  downloadBlob(new Blob([blob], { type: 'image/png' }), safeFileName(fileName, '.png'));
}

export async function shareImage(opts: Omit<ShareFileOptions, 'mimeType' | 'extension'>): Promise<ShareResult> {
  return shareFile({ ...opts, mimeType: 'image/png', extension: '.png' });
}

/** Download a remote document as a Blob rather than navigating to a URL. */
export async function downloadUrlAsBlob(url: string, fileName: string, mimeType?: string): Promise<void> {
  const response = await fetch(url, { credentials: 'same-origin' });
  if (!response.ok) throw new Error(`File download failed (${response.status}).`);
  const remoteBlob = await response.blob();
  const blob = new Blob([remoteBlob], { type: mimeType || remoteBlob.type || 'application/octet-stream' });
  downloadBlob(blob, fileName);
}

/* --------------------------- report helpers ----------------------------- */

export const REPORT_ROOT_ID = 'report-export-root';

export const REPORT_TITLES: Record<string, string> = {
  sale_report: 'Sale Report',
  purchase_report: 'Purchase Report',
  day_book: 'Day Book',
  all_transactions: 'All Transactions',
  bill_wise_profit: 'Bill Wise Profit',
  profit_and_loss: 'Profit and Loss',
  cashflow: 'Cash Flow',
  balance_sheet: 'Balance Sheet',
  trial_balance: 'Trial Balance',
  party_statement: 'Party Ledger',
  party_wise_profit: 'Party Wise Profit and Loss',
  all_parties_report: 'All Parties',
  sale_purchase_by_party: 'Sale Purchase By Party',
  gst_report: 'GST Report',
  rcm_account: 'RCM Account',
  tax_ledger: 'Tax Ledger',
  brs_statement: 'BRS Statement',
  audit_log: 'Audit Log',
  journal_ledger: 'Journal Ledger',
};

const safeName = (s: string) => s.replace(/[^\w\-]+/g, '_').replace(/_+/g, '_').replace(/^_|_$/g, '');

export async function runReportExport(
  mode: 'download' | 'share',
  reportId: string | null,
  companyName?: string,
  onStatus: StatusFn = showToast
) {
  const root = document.getElementById(REPORT_ROOT_ID);
  if (!root || !reportId) {
    onStatus('Open a report first');
    return;
  }
  const title = REPORT_TITLES[reportId] || 'Report';
  const stamp = new Date().toISOString().slice(0, 10);
  const fileName = `${safeName(title)}_${stamp}.pdf`;
  try {
    onStatus('Preparing PDF...');
    const blob = await buildPdf({ element: root, fileName });
    if (mode === 'download') {
      downloadPdf(blob, fileName);
      onStatus('PDF downloaded successfully.');
      return;
    }
    const text = `${title}${companyName ? ` - ${companyName}` : ''} (${stamp}). Please find the attached document.`;
    await sharePdf({ blob, fileName, title, text, onStatus });
  } catch (err) {
    console.error('Report export failed:', err);
    onStatus('PDF could not be created. Please try again.');
  }
}


// Simple one-page detail PDF (used where there is no on-screen document, e.g. an e-way bill record)
export async function downloadDetailsPdf(title: string, rows: [string, string][], fileName: string) {
  const { PDFDocument, StandardFonts, rgb } = await import('pdf-lib');
  const doc = await PDFDocument.create();
  const page = doc.addPage([595, 842]);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const bold = await doc.embedFont(StandardFonts.HelveticaBold);
  let y = 790;
  page.drawText(title, { x: 40, y, size: 18, font: bold, color: rgb(0.1, 0.1, 0.2) });
  y -= 14;
  page.drawLine({ start: { x: 40, y }, end: { x: 555, y }, thickness: 1, color: rgb(0.7, 0.7, 0.75) });
  y -= 26;
  for (const [k, v] of rows) {
    if (y < 60) break;
    page.drawText(k, { x: 40, y, size: 10, font: bold, color: rgb(0.3, 0.3, 0.35) });
    page.drawText(String(v ?? '-').slice(0, 70), { x: 200, y, size: 10, font });
    y -= 20;
  }
  const bytes = await doc.save();
  downloadBlob(new Blob([bytes as any], { type: 'application/pdf' }), fileName);
}
